---
title: 'My Blog Post'
date: '2023-05-23T14:57:07.322Z'
author: 'Daniel K'
isValid: 1
---

Understanding how the chatbot works
Here we need to take a pit stop and take a look at how the MessageParser and ActionProvider interacts to make our bot take action.

When the bot is initialized, the initialMessages property from the config is put into the chatbot's internal state in a property called messages, which is used to render messages to the screen.

Moreover, when we write and push the submit button in the chat field, our MessageParser (which we passed as props to the chatbot) is calling its parse method. This is why this method must be implemented.

Let's take a closer look at the MessageParser starter code:

class MessageParser {
  constructor(actionProvider) {
    this.actionProvider = actionProvider;
  }

  parse(message) {
    ... parse logic
  }
}
If we look closely, this method is constructed with an actionProvider. This is the same ActionProvider class that we pass as props to the chatbot. This means that we control two things - how the message is parsed, and what action to take based on said parsing.

Let's use this information to create a simple chatbot response. First alter the MessageParser like this:

class MessageParser {
  constructor(actionProvider) {
    this.actionProvider = actionProvider;
  }

  parse(message) {
    const lowerCaseMessage = message.toLowerCase()
    
    if (lowerCaseMessage.includes("hello")) {
      this.actionProvider.greet()
    }
  }
}

export default MessageParser
Now our MessageParser is receiving the user message, checking if it includes the word "hello". If it does, it calls the greet method on the actionProvider.
